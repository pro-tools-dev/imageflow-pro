@echo off
echo Starting ImageFlow Pro...
echo.
echo If this is your first time running, please install Node.js:
echo https://nodejs.org/
echo.
echo Then run: npm install && npm start
echo.
pause
